package com.samir.evosim

object NamePool {
    val names = listOf(
        "Anuaki","Velkar","Teshari","Orun","Kaldrin","Sumerai","Narekh","Ilvar","Zorakai","Taruq",
        "Oshari","Keshar","Namar","Varakai","Ashurim","Kelari","Doran","Mireth","Sakari","Ulmar",
        "Arukai","Belesh","Cyran","Dameri","Eshkar","Falun","Gorath","Harakai","Ilyr","Jorun",
        "Karashi","Lumer","Makar","Nerakai","Othar","Parun","Qesh","Ravari","Selukar","Tamar",
        "Urashi","Veyran","Weshar","Xandri","Yurak","Zemari","Avaru","Beshin","Corakai","Darun",
        "Enkari","Farym","Geshar","Hadrim","Iskari","Javaru","Khorin","Leshar","Merakai","Norun",
        "Odrin","Peshar","Qamaru","Rethin","Sorakai","Temur","Ularin","Veshari","Warak","Xerun",
        "Yashari","Zorun","Akesh","Borakai","Calun","Dreshar","Elaru","Ferakai","Gorun","Heshari",
        "Irakai","Jeshar","Korun","Lashari","Morakai","Neshar","Orakai","Perun","Qorash","Rashari",
        "Senkar","Torakai","Uresh","Varun","Weshari","Xorakai","Yenkar","Zashari","Ankar","Boruq"
    )
}
