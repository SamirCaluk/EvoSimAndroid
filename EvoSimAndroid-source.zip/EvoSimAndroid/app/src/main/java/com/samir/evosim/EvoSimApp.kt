package com.samir.evosim

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlin.math.floor

private val Ink = Color(0xFFF3F5F7)
private val Muted = Color(0xFFADB5C2)
private val Panel = Color(0xFF171B22)
private val Back = Color(0xFF0E1116)
private val Accent = Color(0xFF75A7FF)
private val polityColors = listOf(
    Color(0xFF4E79A7), Color(0xFFF28E2B), Color(0xFFE15759), Color(0xFF76B7B2),
    Color(0xFF59A14F), Color(0xFFEDC948), Color(0xFFB07AA1), Color(0xFFFF9DA7)
)

@Composable
fun EvoSimApp(vm: SimulationViewModel = viewModel()) {
    val s by vm.state.collectAsStateWithLifecycle()
    var selectedPolityId by remember { mutableStateOf<Int?>(null) }
    val config = LocalConfiguration.current
    val landscape = config.screenWidthDp > config.screenHeightDp

    MaterialTheme(colorScheme = darkColorScheme(primary = Accent, background = Back, surface = Panel)) {
        Surface(modifier = Modifier.fillMaxSize(), color = Back) {
            if (landscape) {
                Row(Modifier.fillMaxSize().padding(10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Column(Modifier.weight(1.65f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        ControlBar(s, vm)
                        WorldMap(s, selectedPolityId, { selectedPolityId = it }, Modifier.weight(1f).fillMaxWidth())
                    }
                    SidePanel(s, selectedPolityId, Modifier.weight(1f).fillMaxHeight())
                }
            } else {
                Column(Modifier.fillMaxSize().padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    ControlBar(s, vm)
                    WorldMap(s, selectedPolityId, { selectedPolityId = it }, Modifier.fillMaxWidth().weight(1.15f))
                    SidePanel(s, selectedPolityId, Modifier.fillMaxWidth().weight(0.85f))
                }
            }
        }

        s.popup?.let { event ->
            AlertDialog(
                onDismissRequest = { vm.dismissPopup() },
                confirmButton = { Button(onClick = { vm.dismissPopupAndContinue() }) { Text("Continue") } },
                dismissButton = { TextButton(onClick = { vm.dismissPopup() }) { Text("Stay paused") } },
                title = { Text(event.title) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        AssistChip(onClick = {}, label = { Text(event.kind.name) })
                        Text(yearLabel(event.year), color = Muted)
                        Text(event.body)
                    }
                }
            )
        }
    }
}

@Composable
private fun ControlBar(s: SimulationState, vm: SimulationViewModel) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
        Column(Modifier.fillMaxWidth().padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(yearLabel(s.year), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.SemiBold)
                    Text("Population ${formatPopulation(s.population)}", color = Muted)
                }
                Text(if (s.running) "RUNNING" else "PAUSED", color = if (s.running) Accent else Muted, fontWeight = FontWeight.Bold)
            }
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(onClick = { vm.run() }, enabled = !s.running) { Text("▶ Run") }
                OutlinedButton(onClick = { vm.pause() }) { Text("Pause") }
                OutlinedButton(onClick = { vm.step() }) { Text("+100 y") }
                OutlinedButton(onClick = { vm.reset() }) { Text("New world") }
                listOf(1, 5, 20, 100).forEach { speed ->
                    FilterChip(
                        selected = vm.speedMultiplier == speed,
                        onClick = { vm.speedMultiplier = speed },
                        label = { Text("${speed}×") }
                    )
                }
            }
        }
    }
}

@Composable
private fun WorldMap(
    s: SimulationState,
    selectedPolityId: Int?,
    onSelect: (Int?) -> Unit,
    modifier: Modifier = Modifier
) {
    Card(modifier = modifier, colors = CardDefaults.cardColors(containerColor = Panel)) {
        Column(Modifier.fillMaxSize().padding(8.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("WORLD MAP", fontWeight = FontWeight.Bold)
                Text("Tap a region", color = Muted)
            }
            Spacer(Modifier.height(6.dp))
            Box(Modifier.fillMaxSize()) {
                Canvas(
                    modifier = Modifier.fillMaxSize().pointerInput(s.regions, s.polities) {
                        detectTapGestures { tap ->
                            val cols = 12
                            val rows = 7
                            val cw = size.width / cols
                            val ch = size.height / rows
                            val x = floor(tap.x / cw).toInt().coerceIn(0, cols - 1)
                            val y = floor(tap.y / ch).toInt().coerceIn(0, rows - 1)
                            val region = s.regions.getOrNull(y * cols + x)
                            onSelect(region?.ownerId)
                        }
                    }
                ) {
                    val cols = 12
                    val rows = 7
                    val cw = size.width / cols
                    val ch = size.height / rows
                    s.regions.forEach { r ->
                        val owner = s.polities.firstOrNull { it.id == r.ownerId }
                        val base = if (r.population < 1.0) Color(0xFF243128) else polityColors[(owner?.colorIndex ?: 0) % polityColors.size]
                        val alpha = if (r.population < 1.0) 0.32f else (0.35f + (r.population / (r.carryingCapacity.coerceAtLeast(1.0))).coerceIn(0.0, 1.0).toFloat() * 0.55f)
                        val rect = Rect(r.x * cw, r.y * ch, (r.x + 1) * cw, (r.y + 1) * ch)
                        drawRect(base.copy(alpha = alpha), topLeft = rect.topLeft, size = rect.size)
                        val selected = selectedPolityId != null && owner?.id == selectedPolityId
                        drawRect(if (selected) Accent else Color(0xFF0E1116), topLeft = rect.topLeft, size = rect.size, style = Stroke(width = if (selected) 4f else 1.2f))
                    }
                }
                Column(Modifier.align(Alignment.BottomStart).background(Back.copy(alpha = .82f), RoundedCornerShape(10.dp)).padding(8.dp)) {
                    Text("Tech W${s.weaponTech}  •  Food ${s.foodTech}  •  ${s.polities.size} polities", color = Ink)
                    Text("Regional carrying capacity • no global population cap", color = Muted, style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}

@Composable
private fun SidePanel(s: SimulationState, selectedPolityId: Int?, modifier: Modifier = Modifier) {
    val selected = s.polities.firstOrNull { it.id == selectedPolityId }
    Card(modifier = modifier, colors = CardDefaults.cardColors(containerColor = Panel)) {
        LazyColumn(
            Modifier.fillMaxSize().padding(10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                Text(selected?.name ?: "Simulation", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                if (selected != null) {
                    Text("Population ${formatPopulation(selected.population)}", color = Muted)
                    Text("Weapons W${selected.weaponTech}  •  Food ${selected.foodTech}  •  Org ${selected.organization}", color = Muted)
                    Text("INT %.1f  •  PHY %.1f".format(selected.intelligence, selected.physique), color = Muted)
                } else {
                    Text("Tap a colored region to inspect its polity.", color = Muted)
                }
            }
            item {
                HorizontalDivider()
                Text("World", fontWeight = FontWeight.Bold)
                StatRow("Population", formatPopulation(s.population))
                StatRow("War deaths", formatPopulation(s.warDeaths))
                StatRow("Intelligence", "%.2f".format(s.intelligence))
                StatRow("Physique", "%.2f".format(s.physique))
                StatRow("Religions", s.religions.size.toString())
            }
            item {
                HorizontalDivider()
                Text("Recent events", fontWeight = FontWeight.Bold)
            }
            items(s.events.take(18)) { e ->
                Column(Modifier.fillMaxWidth()) {
                    Text(e.title, fontWeight = if (e.major) FontWeight.Bold else FontWeight.Medium)
                    Text("${yearLabel(e.year)} • ${e.kind.name}", color = Muted, style = MaterialTheme.typography.bodySmall)
                    Text(e.body, style = MaterialTheme.typography.bodySmall)
                }
            }
            if (s.events.isEmpty()) item { Text("Press Run and let history happen.", color = Muted) }
        }
    }
}

@Composable
private fun StatRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = Muted)
        Text(value, fontWeight = FontWeight.SemiBold)
    }
}
