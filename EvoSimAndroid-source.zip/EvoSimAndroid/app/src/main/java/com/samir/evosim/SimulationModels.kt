package com.samir.evosim

data class Region(
    val id: Int,
    val x: Int,
    val y: Int,
    val fertility: Double,
    val climate: Double,
    val water: Double,
    val areaFactor: Double,
    val ownerId: Int? = null,
    val population: Double = 0.0,
    val carryingCapacity: Double = 0.0
)

data class Polity(
    val id: Int,
    val name: String,
    val colorIndex: Int,
    val population: Double,
    val weaponTech: Int,
    val foodTech: Int,
    val organization: Int,
    val physique: Double,
    val intelligence: Double,
    val religionId: Int? = null
)

data class Religion(
    val id: Int,
    val name: String,
    val parentId: Int? = null,
    val deityCentered: Boolean = true,
    val coercion: Double = 0.0
)

enum class EventKind { TECHNOLOGY, WAR, RELIGION, DISASTER, STATE, MIGRATION }

data class SimEvent(
    val year: Int,
    val title: String,
    val body: String,
    val kind: EventKind,
    val major: Boolean = false
)

data class SimulationState(
    val year: Int = -200_000,
    val running: Boolean = false,
    val population: Double = 200.0,
    val intelligence: Double = 100.0,
    val physique: Double = 100.0,
    val health: Double = 100.0,
    val sociability: Double = 100.0,
    val weaponTech: Int = 0,
    val foodTech: Int = 0,
    val organization: Int = 0,
    val warDeaths: Double = 0.0,
    val regions: List<Region> = emptyList(),
    val polities: List<Polity> = emptyList(),
    val religions: List<Religion> = emptyList(),
    val events: List<SimEvent> = emptyList(),
    val popup: SimEvent? = null,
    val seed: Long = 0L
)
