package com.samir.evosim

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class SimulationViewModel : ViewModel() {
    private val engine = SimulationEngine()
    private val _state = MutableStateFlow(engine.current())
    val state: StateFlow<SimulationState> = _state.asStateFlow()
    private var runJob: Job? = null
    var speedMultiplier = 20

    fun run() {
        if (runJob != null) return
        _state.value = engine.setRunning(true)
        runJob = viewModelScope.launch {
            while (isActive && _state.value.year < 2000) {
                repeat(speedMultiplier) {
                    if (_state.value.popup != null) return@repeat
                    _state.value = engine.step(100)
                }
                if (_state.value.popup != null) {
                    pause()
                    break
                }
                delay(120)
            }
        }
    }

    fun pause() {
        runJob?.cancel(); runJob = null
        _state.value = engine.setRunning(false)
    }

    fun reset() {
        pause()
        _state.value = engine.reset()
    }

    fun step() {
        pause()
        _state.value = engine.step(100)
    }

    fun dismissPopupAndContinue() {
        _state.value = engine.dismissPopup()
        run()
    }

    fun dismissPopup() {
        _state.value = engine.dismissPopup()
    }
}
