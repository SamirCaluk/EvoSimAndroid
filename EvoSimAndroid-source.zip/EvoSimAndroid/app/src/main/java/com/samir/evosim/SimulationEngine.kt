package com.samir.evosim

import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.random.Random

class SimulationEngine(seed: Long = System.currentTimeMillis()) {
    private var random = Random(seed)
    private var state = createInitialState(seed)
    private val usedNames = mutableSetOf<String>()
    private var nextPolityId = 1
    private var nextReligionId = 1

    fun current(): SimulationState = state

    fun reset(seed: Long = System.currentTimeMillis()): SimulationState {
        random = Random(seed)
        usedNames.clear()
        nextPolityId = 1
        nextReligionId = 1
        state = createInitialState(seed)
        return state
    }

    fun setRunning(running: Boolean): SimulationState {
        state = state.copy(running = running)
        return state
    }

    fun dismissPopup(): SimulationState {
        state = state.copy(popup = null)
        return state
    }

    fun step(years: Int = 100): SimulationState {
        var s = state.copy(year = min(2000, state.year + years))
        s = advanceTechnology(s)
        s = advanceTraits(s)
        s = updateRegionalDemography(s, years)
        s = maybeCreateReligion(s)
        s = maybeCreatePolity(s)
        s = maybeSchism(s)
        s = maybeWar(s)
        s = maybeDisaster(s)
        s = normalizePolityPopulation(s)
        state = s
        return state
    }

    private fun createInitialState(seed: Long): SimulationState {
        val width = 12
        val height = 7
        val regions = buildList {
            var id = 0
            for (y in 0 until height) for (x in 0 until width) {
                val centerBias = 1.0 - (((x - 5.5) * (x - 5.5) + (y - 3.0) * (y - 3.0)) / 60.0).coerceIn(0.0, 0.7)
                add(
                    Region(
                        id = id++, x = x, y = y,
                        fertility = (0.55 + random.nextDouble() * 0.55) * centerBias,
                        climate = 0.65 + random.nextDouble() * 0.35,
                        water = 0.55 + random.nextDouble() * 0.45,
                        areaFactor = 0.8 + random.nextDouble() * 0.4
                    )
                )
            }
        }.toMutableList()

        val startIndex = (height / 2) * width + (width / 2)
        regions[startIndex] = regions[startIndex].copy(population = 200.0, ownerId = 0)
        val founder = Polity(0, "Founders", 0, 200.0, 0, 0, 0, 100.0, 100.0)
        return SimulationState(regions = regions, polities = listOf(founder), seed = seed)
    }

    private fun regionalK(r: Region, foodTech: Int, weaponTech: Int): Double {
        val subsistence = when (foodTech) {
            0 -> 900.0
            1 -> 1_200.0
            2 -> 1_800.0
            3 -> 2_600.0
            4 -> 4_500.0
            5 -> 18_000.0
            6 -> 95_000.0
            7 -> 180_000.0
            else -> 280_000.0
        }
        val huntingBoost = 1.0 + min(3, weaponTech) * 0.07
        return subsistence * r.fertility * r.climate * r.water * r.areaFactor * huntingBoost
    }

    private fun updateRegionalDemography(s: SimulationState, years: Int): SimulationState {
        val regions = s.regions.map { r ->
            val k = regionalK(r, s.foodTech, s.weaponTech)
            if (r.population <= 0.0) r.copy(carryingCapacity = k)
            else {
                val baseR = when {
                    s.foodTech >= 6 -> 0.0026
                    s.foodTech >= 5 -> 0.0014
                    s.foodTech >= 3 -> 0.00065
                    else -> 0.00035
                }
                val growthFactor = exp(baseR * years * (1.0 - r.population / max(1.0, k)))
                r.copy(population = max(0.0, r.population * growthFactor), carryingCapacity = k)
            }
        }.toMutableList()

        // Geographic expansion: crowded occupied cells spill into adjacent empty cells.
        val width = 12
        fun neighbors(index: Int): List<Int> {
            val x = index % width
            val y = index / width
            return listOf(x-1 to y, x+1 to y, x to y-1, x to y+1)
                .filter { (nx, ny) -> nx in 0 until 12 && ny in 0 until 7 }
                .map { (nx, ny) -> ny * width + nx }
        }
        for (i in regions.indices.shuffled(random)) {
            val r = regions[i]
            if (r.population > r.carryingCapacity * 0.72 && r.population > 120.0) {
                val options = neighbors(i).filter { regions[it].population < 10.0 }
                if (options.isNotEmpty() && random.nextDouble() < 0.30) {
                    val target = options.random(random)
                    val migrants = r.population * (0.05 + random.nextDouble() * 0.08)
                    regions[i] = r.copy(population = r.population - migrants)
                    regions[target] = regions[target].copy(population = migrants, ownerId = r.ownerId)
                }
            }
        }

        val total = regions.sumOf { it.population }
        return s.copy(regions = regions, population = total)
    }

    private fun advanceTraits(s: SimulationState): SimulationState {
        val weaponDamp = if (s.weaponTech >= 4) 0.25 else 1.0
        return s.copy(
            intelligence = s.intelligence + 0.0007 * (1 + s.organization * 0.15),
            physique = s.physique + 0.00045 * weaponDamp,
            health = s.health + 0.0005,
            sociability = s.sociability + 0.00055 * (1 + s.organization * 0.10)
        )
    }

    private fun advanceTechnology(s: SimulationState): SimulationState {
        var result = s
        val occupied = s.regions.count { it.population > 20 }
        val populationFactor = ln(max(200.0, s.population) / 200.0 + 1.0)
        val networkFactor = 1.0 + occupied / 20.0

        fun discover(condition: Boolean, chance: Double, title: String, body: String, apply: (SimulationState) -> SimulationState) {
            if (condition && random.nextDouble() < chance * networkFactor * (1 + populationFactor * 0.08)) {
                result = apply(result)
                result = pushEvent(result, SimEvent(result.year, title, body, EventKind.TECHNOLOGY, major = true))
            }
        }

        discover(result.weaponTech == 0 && result.year > -140_000, 0.008, "Improved stone weapons discovered", "Knapping and hafting techniques make hunting weapons more reliable.") { it.copy(weaponTech = 1) }
        discover(result.weaponTech == 1 && result.year > -90_000, 0.009, "Projectile weapons discovered", "Hunters can now kill from greater distance; raw physique matters slightly less in combat.") { it.copy(weaponTech = 2) }
        discover(result.weaponTech == 2 && result.year > -45_000, 0.010, "Advanced projectile systems", "Improved shafts, points and coordinated hunting raise military and hunting effectiveness.") { it.copy(weaponTech = 3) }
        discover(result.foodTech == 0 && result.year > -35_000, 0.010, "Food storage developed", "Communities preserve surpluses, allowing larger settlements and specialists.") { it.copy(foodTech = 3) }
        discover(result.foodTech == 3 && result.year > -16_000, 0.012, "Cultivation discovered", "Some communities deliberately tend useful plants and begin investing in fixed land.") { it.copy(foodTech = 5) }
        discover(result.foodTech == 5 && result.year > -11_000, 0.014, "Agriculture discovered", "Reliable food production sharply raises local carrying capacity.") { it.copy(foodTech = 6, organization = max(2, it.organization)) }
        discover(result.weaponTech == 3 && result.foodTech >= 5 && result.year > -7_000, 0.013, "Copper discovered", "Metalworking produces prestige objects and increasingly effective tools and weapons.") { it.copy(weaponTech = 6, organization = max(3, it.organization)) }
        discover(result.weaponTech == 6 && result.year > -4_500, 0.015, "Bronze discovered", "Alloyed weapons and tools improve durability and battlefield effectiveness.") { it.copy(weaponTech = 8, organization = max(4, it.organization)) }
        return result
    }

    private fun maybeCreateReligion(s: SimulationState): SimulationState {
        if (s.religions.isNotEmpty() || s.year < -60_000) return s
        if (random.nextDouble() < 0.0035) {
            val religion = Religion(nextReligionId++, "${randomName()} Creator Faith", deityCentered = true, coercion = random.nextDouble() * 0.25)
            return pushEvent(s.copy(religions = listOf(religion)), SimEvent(s.year, "Organized creator religion emerges", "${religion.name} begins spreading between communities.", EventKind.RELIGION, true))
        }
        return s
    }

    private fun maybeSchism(s: SimulationState): SimulationState {
        if (s.religions.isEmpty() || random.nextDouble() > 0.0025) return s
        val parent = s.religions.random(random)
        val child = Religion(nextReligionId++, "${randomName()} Reform", parent.id, true, (parent.coercion + random.nextDouble(-0.1, 0.15)).coerceIn(0.0, 0.8))
        return pushEvent(s.copy(religions = s.religions + child), SimEvent(s.year, "Religious schism", "${child.name} splits from ${parent.name}.", EventKind.RELIGION, true))
    }

    private fun maybeCreatePolity(s: SimulationState): SimulationState {
        val occupied = s.regions.count { it.population > 100 }
        val target = min(18, max(1, 1 + occupied / 5 + s.organization))
        if (s.polities.size >= target || random.nextDouble() > 0.08) return s
        val polity = Polity(
            id = nextPolityId++, name = randomName(), colorIndex = nextPolityId % 8,
            population = max(2_000.0, s.population / target), weaponTech = max(0, s.weaponTech - random.nextInt(0, 2)),
            foodTech = s.foodTech, organization = max(0, s.organization - random.nextInt(0, 2)),
            physique = s.physique + random.nextDouble(-5.0, 8.0), intelligence = s.intelligence + random.nextDouble(-4.0, 6.0),
            religionId = s.religions.randomOrNull(random)?.id
        )
        val updatedRegions = s.regions.toMutableList()
        val candidate = updatedRegions.indices.filter { updatedRegions[it].population > 100 && updatedRegions[it].ownerId in listOf(null, 0) }
        if (candidate.isNotEmpty()) {
            val idx = candidate.random(random)
            updatedRegions[idx] = updatedRegions[idx].copy(ownerId = polity.id)
        }
        return pushEvent(s.copy(polities = s.polities + polity, regions = updatedRegions), SimEvent(s.year, "${polity.name} emerges", "A new independent polity consolidates territory.", EventKind.STATE, true))
    }

    private fun maybeWar(s: SimulationState): SimulationState {
        val contenders = s.polities.filter { it.id != 0 && it.population > 1_000 }
        if (contenders.size < 2 || s.year < -25_000 || random.nextDouble() > 0.018) return s
        val a = contenders.random(random)
        var b = contenders.random(random)
        if (a.id == b.id) return s

        fun power(p: Polity): Double = p.population.pow(0.58) * (p.physique / 100.0).pow(0.28) *
            (1 + p.weaponTech * 0.22).pow(1.4) * (1 + p.organization * 0.19).pow(0.95) * random.nextDouble(0.85, 1.15)

        val pa = power(a); val pb = power(b)
        val winner = if (pa >= pb) a else b
        val loser = if (winner.id == a.id) b else a
        val casualties = min(a.population, b.population) * random.nextDouble(0.01, 0.08)
        val weakerPhysically = winner.physique < loser.physique

        val updated = s.polities.map { p ->
            when (p.id) {
                winner.id -> p.copy(population = max(200.0, p.population - casualties * 0.35))
                loser.id -> p.copy(population = max(200.0, p.population - casualties * 0.65))
                else -> p
            }
        }
        val detail = if (weakerPhysically) " The victor was physically weaker, but technology and organization overcame the disadvantage." else ""
        return pushEvent(
            s.copy(polities = updated, population = max(200.0, s.population - casualties), warDeaths = s.warDeaths + casualties),
            SimEvent(s.year, "${winner.name} defeats ${loser.name}", "Estimated casualties: ${formatPopulation(casualties)}.$detail", EventKind.WAR, major = casualties > 10_000 || weakerPhysically)
        )
    }

    private fun maybeDisaster(s: SimulationState): SimulationState {
        if (random.nextDouble() > 0.003) return s
        val fraction = random.nextDouble(0.01, 0.06)
        val loss = s.population * fraction
        val regions = s.regions.map { it.copy(population = it.population * (1.0 - fraction)) }
        return pushEvent(s.copy(population = s.population - loss, regions = regions), SimEvent(s.year, "Famine or epidemic", "${formatPopulation(loss)} people die during a major demographic shock.", EventKind.DISASTER, major = loss > 50_000))
    }

    private fun normalizePolityPopulation(s: SimulationState): SimulationState {
        if (s.polities.isEmpty()) return s
        val total = s.polities.sumOf { it.population }
        if (total <= 0) return s
        return s.copy(polities = s.polities.map { it.copy(population = it.population / total * s.population) })
    }

    private fun pushEvent(s: SimulationState, event: SimEvent): SimulationState {
        return s.copy(events = (listOf(event) + s.events).take(60), popup = if (event.major) event else s.popup)
    }

    private fun randomName(): String {
        val remaining = NamePool.names.filterNot { it in usedNames }
        val base = (remaining.ifEmpty { NamePool.names }).random(random)
        usedNames += base
        return base
    }
}

fun formatPopulation(value: Double): String = when {
    value >= 1_000_000_000 -> "%.2f B".format(value / 1_000_000_000)
    value >= 1_000_000 -> "%.2f M".format(value / 1_000_000)
    value >= 1_000 -> "%.1f K".format(value / 1_000)
    else -> value.toInt().toString()
}

fun yearLabel(year: Int): String = when {
    year < 0 -> "${-year} BC"
    year == 0 -> "1 BC / AD"
    else -> "$year AD"
}
