# EvoSim Android — v0.1

A local-first Android/Jetpack Compose prototype for the prehistoric evolution + civilization simulation discussed in ChatGPT.

## Included
- Simulation from 200,000 BC to 2000 AD in 100-year ticks.
- Run / Pause / +100 years / New world.
- 1x, 5x, 20x and 100x speeds.
- Regional population model with local carrying capacity (no fixed 3-million global cap).
- Geographic population expansion into neighboring cells.
- 100 random polity/tribe names (Anuaki, Velkar, Teshari, etc.).
- Technology discoveries with major-event popup dialogs.
- Food storage, cultivation, agriculture, copper and bronze milestones.
- Creator religion emergence and random schisms.
- New polity/state formation.
- Warfare where weapons and organization can outweigh physique.
- Famine/epidemic shocks.
- Portrait and landscape adaptive UI.
- Tap map regions to inspect a polity.

## Open and run
1. Install a current Android Studio version.
2. Open the `EvoSimAndroid` folder as a project.
3. Let Gradle sync/download dependencies.
4. Select your Android phone or emulator.
5. Click Run.

The build configuration uses AGP 8.13.2, Gradle 8.13, Kotlin 2.2.21, JDK 17, compileSdk/targetSdk 36, and the stable Compose BOM 2026.06.01.

## Important model note
This is a fictional toy simulation, not a reconstruction of real human history. The constants are deliberately exposed in `SimulationEngine.kt` so we can calibrate them together.

## Next upgrades worth doing
- Proper generated terrain rather than a rectangular regional grid.
- Rivers, mountains, deserts and coastlines affecting movement and carrying capacity.
- Territory conquest and changing borders after wars.
- Diplomacy, alliances and tributaries.
- Separate military units, army size, logistics and weapon inventories.
- Technology diffusion via trade/conquest rather than global discoveries.
- Religion followers by region and conversion/persecution systems.
- Save/load simulation seeds and histories.
- Charts for population, traits, technology and casualties.
- A dedicated near-fullscreen map mode on Android.

## Phone-only GitHub build
This source can be stored in the repository as `EvoSimAndroid-source.zip` and built by `.github/workflows/build-apk.yml`. The GitHub Actions workflow unpacks the source, installs Android SDK 36, builds the debug APK, and uploads it as the `EvoSim-debug-apk` artifact.
